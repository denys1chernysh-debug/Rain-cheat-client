#!/usr/bin/env bash
# Run in GitHub Codespaces from the project folder:  bash build.sh
set -e
if [ -f "$HOME/.sdkman/bin/sdkman-init.sh" ]; then
  source "$HOME/.sdkman/bin/sdkman-init.sh"
  if ! java -version 2>&1 | grep -q '"25'; then
    sdk install java 25-tem || sdk install java "$(sdk list java | grep -o '25\.[0-9.]*-tem' | head -1)"
    sdk use java "$(sdk list java | grep -o '25\.[0-9.]*-tem' | head -1)" || true
  fi
  if [ ! -f gradlew ]; then
    command -v gradle >/dev/null || sdk install gradle
  fi
fi
java -version
if [ ! -f gradlew ]; then gradle wrapper --gradle-version 9.5.1; fi
chmod +x gradlew
./gradlew build --no-daemon
cp build/libs/Rain-Client-1.0.0.jar ./Rain-Client-1.0.0.jar
ls -la Rain-Client-1.0.0.jar
