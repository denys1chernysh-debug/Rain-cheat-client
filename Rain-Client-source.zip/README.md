# Rain Client 1.0.0 (Fabric, Minecraft 26.2, Java 25)

## Build (GitHub Codespaces)
    bash build.sh
Result: `Rain-Client-1.0.0.jar` in this folder (also build/libs/). Put it in your mods folder with Fabric API.

This source was written WITHOUT being able to compile it (no network in the authoring sandbox).
Expect to fix a few Mojang-name differences on the first build. Paste the compiler errors back and they get fixed.
Version numbers (gradle.properties) came from public pages: loader 0.19.5, loom 1.17-SNAPSHOT, Fabric API 0.154.0+26.2.
If one does not resolve, use the version Fabric's template page lists for 26.2.

## Use
RIGHT SHIFT opens/closes the menu. Click a card to expand settings, click the switch to toggle, click "Keybind" then press a key.
Config: `.minecraft/config/rain-client.json` (auto-saved).

## Honest limitations
- NO in-world outlines/ESP boxes/trajectory lines. World rendering is the most version-fragile API, so
  Storage ESP, Block ESP, Auto Crystal, Wind/Pearl, Base Finder show a HUD list (coords, distance, reasons) instead.
- Hitboxes / Silent Aim use the client-side glow outline; outline thickness and per-module colors are not possible with it.
  For real hitbox boxes use F3+B.
- Triggerbot, Auto Clicker, W-Tap, Auto Totem, Auto Mace, Breach Swap, Anchor Macro, Auto Crystal DO NOT act for you
  (no attacking, clicking, swapping or placing): they measure, display and advise.
- Aim Assist rotates your camera; use only where that is allowed.
- Silent Aim is visualization only; the server decides hit registration.
- Base Finder: heuristic, uses only chunk data your client has, no anti-xray bypass. Villages/mineshafts/dungeons cause false positives.
  Underground-room-shape detection is NOT implemented.
- GUI: no icons, accent colors, blur, UI scale or animation settings. Movement/Player/Render/Utility/HUD categories are empty.
