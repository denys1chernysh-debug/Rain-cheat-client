package com.rain.modules;

import com.rain.module.*;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.Vec3;
import java.util.ArrayList;
import java.util.List;

/** Projectile tracker with a simple physics prediction of where each projectile lands. */
public class WindPearl extends Module {
    private final Setting<Boolean> trajectory = bool("Trajectory display", true);
    private final Setting<Boolean> indicators = bool("Projectile indicators", true);
    private final Setting<Boolean> timing = bool("Timing feedback", true);
    private final Setting<Boolean> ownOnly = bool("Only my projectiles", true);

    public WindPearl() {
        super("Wind Charge & Pearl Catch", "Tracks ender pearls and wind charges, shows their direction/speed and predicts the impact point and time.", Category.CRYSTAL_MACE);
    }

    @Override protected void onTick() {
        List<String> l = new ArrayList<>();
        for (Entity e : mc.level.entitiesForRendering()) {
            boolean pearl = e.getType() == EntityType.ENDER_PEARL, wind = e.getType() == EntityType.WIND_CHARGE;
            if (!pearl && !wind) continue;
            if (ownOnly.value && !(e instanceof Projectile p && p.getOwner() == mc.player)) continue;
            Vec3 v = e.getDeltaMovement();
            String line = (pearl ? "Pearl" : "Wind") + " " + Targeting.d(mc.player.distanceTo(e)) + "m, " + Targeting.d(v.length() * 20) + " b/s, " + Targeting.rel(e.getX() - mc.player.getX(), e.getZ() - mc.player.getZ());
            if (!indicators.value) line = pearl ? "Pearl" : "Wind";
            l.add(line);
            if (trajectory.value || timing.value) {
                Vec3 pos = e.position(), vel = v;
                double g = pearl ? 0.03 : 0.0, drag = pearl ? 0.99 : 1.0;
                int t = 0; boolean hit = false;
                for (; t < 200; t++) {
                    pos = pos.add(vel);
                    if (!mc.level.getBlockState(BlockPos.containing(pos)).isAir()) { hit = true; break; }
                    vel = vel.scale(drag).add(0, -g, 0);
                }
                if (hit) l.add("  impact ~" + (int) pos.x + " " + (int) pos.y + " " + (int) pos.z + (timing.value ? " in " + t + " ticks (" + Targeting.d(t / 20.0) + "s)" : ""));
                else l.add("  no impact within 10s");
            }
            if (l.size() > 10) break;
        }
        if (l.isEmpty()) l.add("No projectiles tracked");
        hud(l.toArray(new String[0]));
    }
}
