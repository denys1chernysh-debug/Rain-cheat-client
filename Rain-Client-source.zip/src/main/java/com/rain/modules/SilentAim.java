package com.rain.modules;

import com.rain.module.*;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

/** Visualization only. It never changes your rotation or what the server registers. */
public class SilentAim extends Module {
    private final Setting<Double> range = num("Target range", 6, 1, 20);
    private final Setting<Double> fov = num("FOV", 120, 10, 360);
    private final Setting<String> prio = choice("Target priority", "Distance", "Distance", "Angle", "Health");
    private final Setting<Boolean> indicator = bool("Target indicator (glow)", true);
    private final Setting<Boolean> players = bool("Target players", true);
    private final Setting<Boolean> mobs = bool("Target mobs", true);
    private LivingEntity glowing;

    public SilentAim() {
        super("Silent Aim", "Shows target selection, hitbox data and camera-vs-target angle. Visualization only: the server decides hit registration from your real camera.", Category.COMBAT);
    }

    @Override protected void onDisable() { clearGlow(); }

    private void clearGlow() { if (glowing != null) { glowing.setGlowingTag(false); glowing = null; } }

    @Override protected void onTick() {
        LivingEntity t = Targeting.best(range.value, fov.value, players.value, mobs.value, prio.value);
        if (t != glowing) clearGlow();
        if (t == null) { hud("No target"); return; }
        if (indicator.value) { t.setGlowingTag(true); glowing = t; } else clearGlow();
        AABB b = t.getBoundingBox();
        hud("Selected: " + t.getName().getString() + " " + Targeting.d(mc.player.distanceTo(t)) + "m",
            "Hitbox " + Targeting.d(b.getXsize()) + " x " + Targeting.d(b.getYsize()) + " x " + Targeting.d(b.getZsize()),
            "Camera offset: yaw " + Targeting.d(Targeting.wrap(Targeting.yawTo(t) - mc.player.getYRot())) + " pitch " + Targeting.d(Targeting.pitchTo(t) - mc.player.getXRot()),
            "Server hit registration uses your real camera,",
            "not this selection (visualization only).");
    }
}
