package com.rain.modules;

import com.rain.module.*;
import net.minecraft.world.phys.Vec3;
import java.util.*;

/** Exploration helper. Tracks explored chunks and points you at destinations; never moves or digs for you. */
public class AutoBaseHunt extends Module {
    private final Setting<Double> searchRadius = num("Search radius (chunks)", 16, 4, 64);
    private final Setting<Boolean> markers = bool("Destination markers", true);
    private final Setting<Boolean> nav = bool("Navigation display", true);
    private final Setting<Boolean> notify = bool("Notifications", false);
    private final Setting<Boolean> manual = bool("Use manual destination", false);
    private final Setting<Double> destX = num("Manual X", 0, -30000000, 30000000);
    private final Setting<Double> destZ = num("Manual Z", 0, -30000000, 30000000);
    private final Set<Long> explored = new HashSet<>();
    private final Set<Long> announced = new HashSet<>();

    public AutoBaseHunt() {
        super("Auto Base Hunt", "Tracks explored chunks, marks Base Finder hits and shows direction/distance to a destination. Navigation help only: it never moves or digs for you.", Category.BASE_HUNTING);
    }

    @Override protected void onEnable() { explored.clear(); announced.clear(); }

    @Override protected void onTick() {
        int pcx = mc.player.blockPosition().getX() >> 4, pcz = mc.player.blockPosition().getZ() >> 4;
        for (int x = -4; x <= 4; x++) for (int z = -4; z <= 4; z++)
            if (mc.level.hasChunk(pcx + x, pcz + z)) explored.add(BaseFinder.key(pcx + x, pcz + z));
        List<String> l = new ArrayList<>();
        l.add("Explored chunks: " + explored.size());
        double tx = 0, tz = 0; String label = null;
        if (manual.value) { tx = destX.value; tz = destZ.value; label = "Manual destination"; }
        else {
            BaseFinder.Det best = null;
            for (BaseFinder.Det d : BaseFinder.results.values()) {
                double dist = Math.hypot(d.cx() - pcx, d.cz() - pcz);
                if (dist > searchRadius.value || d.prob() < 30) continue;
                if (notify.value && announced.add(BaseFinder.key(d.cx(), d.cz()))) chat("marked chunk " + d.cx() + "," + d.cz() + " (" + d.prob() + "%)");
                if (best == null || d.prob() > best.prob()) best = d;
            }
            if (best != null) { tx = best.cx() * 16 + 8; tz = best.cz() * 16 + 8; label = "Best candidate " + best.prob() + "%"; }
        }
        if (label == null && BaseFinder.results.isEmpty()) l.add("Enable Base Finder to get candidates.");
        if (label != null && nav.value) {
            double dx = tx - mc.player.getX(), dz = tz - mc.player.getZ();
            l.add(label + ": " + (int) tx + ", " + (int) tz + " | " + (int) Math.hypot(dx, dz) + "m | " + Targeting.rel(dx, dz));
        } else if (label == null) {
            int best = Integer.MAX_VALUE, bx = 0, bz = 0;
            int r = searchRadius.value.intValue();
            for (int x = -r; x <= r; x += 2) for (int z = -r; z <= r; z += 2) {
                if (explored.contains(BaseFinder.key(pcx + x, pcz + z))) continue;
                int d = x * x + z * z; if (d < best) { best = d; bx = pcx + x; bz = pcz + z; }
            }
            if (best != Integer.MAX_VALUE && nav.value) l.add("Nearest unexplored: chunk " + bx + "," + bz + " | " + Targeting.rel(bx * 16 + 8 - mc.player.getX(), bz * 16 + 8 - mc.player.getZ()));
        }
        if (markers.value) {
            int n = 0;
            for (BaseFinder.Det d : BaseFinder.results.values()) if (d.prob() >= 30 && n++ < 3) l.add("Marker: " + (d.cx() * 16 + 8) + ", " + (d.cz() * 16 + 8) + " (" + d.prob() + "%)");
        }
        hud(l.toArray(new String[0]));
    }
}
