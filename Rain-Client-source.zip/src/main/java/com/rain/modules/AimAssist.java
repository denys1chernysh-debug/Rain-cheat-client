package com.rain.modules;

import com.rain.module.*;
import net.minecraft.world.entity.LivingEntity;

public class AimAssist extends Module {
    private final Setting<Double> range = num("Range", 4.5, 1, 12);
    private final Setting<Double> fov = num("FOV", 90, 10, 360);
    private final Setting<Double> strength = num("Aim strength", 0.3, 0.05, 1);
    private final Setting<Double> speed = num("Aim speed (deg/tick)", 6, 1, 30);
    private final Setting<String> prio = choice("Target priority", "Distance", "Distance", "Angle", "Health");
    private final Setting<Boolean> vert = bool("Vertical aiming", true);
    private final Setting<Boolean> horiz = bool("Horizontal aiming", true);
    private final Setting<Boolean> players = bool("Target players", true);
    private final Setting<Boolean> mobs = bool("Target mobs", true);
    private final Setting<Boolean> onlyAttack = bool("Only while attacking", true);

    public AimAssist() {
        super("Aim Assist", "Smoothly nudges your camera toward the best eligible target in range and FOV. For private practice.", Category.COMBAT);
    }

    @Override protected void onTick() {
        if (mc.screen != null) { hud(); return; }
        LivingEntity t = Targeting.best(range.value, fov.value, players.value, mobs.value, prio.value);
        if (t == null) { hud("No target in range/FOV"); return; }
        boolean active = !onlyAttack.value || mc.options.keyAttack.isDown();
        float yawDiff = Targeting.wrap(Targeting.yawTo(t) - mc.player.getYRot());
        float pitchDiff = Targeting.pitchTo(t) - mc.player.getXRot();
        if (active) {
            if (horiz.value) mc.player.setYRot(mc.player.getYRot() + clamp(yawDiff * strength.value.floatValue(), speed.value.floatValue()));
            if (vert.value) mc.player.setXRot(mc.player.getXRot() + clamp(pitchDiff * strength.value.floatValue(), speed.value.floatValue()));
        }
        hud("Target: " + t.getName().getString() + " " + Targeting.d(mc.player.distanceTo(t)) + "m",
            "Offset: yaw " + Targeting.d(yawDiff) + " pitch " + Targeting.d(pitchDiff) + (active ? " (assisting)" : " (idle)"));
    }

    private static float clamp(float v, float max) { return Math.max(-max, Math.min(max, v)); }
}
