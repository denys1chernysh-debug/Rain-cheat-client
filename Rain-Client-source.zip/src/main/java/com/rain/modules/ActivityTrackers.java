package com.rain.modules;

import com.rain.module.*;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import java.util.ArrayList;
import java.util.List;

/** Entity population tracker for loaded areas. */
public class ActivityTrackers extends Module {
    private final Setting<Boolean> villagers = bool("Track villagers", true);
    private final Setting<Boolean> farm = bool("Track farm animals", true);
    private final Setting<Boolean> others = bool("Track other mobs", true);
    private final Setting<Boolean> players = bool("Track other players", true);
    private final Setting<Double> radius = num("Detection radius", 48, 8, 128);
    private final Setting<Double> interval = num("Update interval (ticks)", 100, 20, 1200);
    private final Setting<Boolean> notify = bool("Notifications", true);
    private final Setting<Boolean> statsOn = bool("Statistics display", true);
    private int tick, v, f, o, p, pv = -1, pf = -1, po = -1, pp = -1, snapshots;
    private int maxV, maxF, maxO, maxP;

    public ActivityTrackers() {
        super("Activity Trackers", "Counts villagers, farm animals, other mobs and players in range, tracks population changes over time and can notify on changes.", Category.BASE_HUNTING);
    }

    @Override protected void onEnable() { tick = 0; pv = pf = po = pp = -1; maxV = maxF = maxO = maxP = 0; snapshots = 0; }

    @Override protected void onTick() {
        if (tick++ % Math.max(1, interval.value.intValue()) == 0 || snapshots == 0) {
            pv = v; pf = f; po = o; pp = p; v = f = o = p = 0;
            for (Entity e : mc.level.entitiesForRendering()) {
                if (e == mc.player || mc.player.distanceTo(e) > radius.value) continue;
                if (e.getType() == EntityType.VILLAGER) v++;
                else if (e instanceof Animal) f++;
                else if (e instanceof Player) p++;
                else if (e instanceof Mob) o++;
            }
            maxV = Math.max(maxV, v); maxF = Math.max(maxF, f); maxO = Math.max(maxO, o); maxP = Math.max(maxP, p);
            if (snapshots++ > 0 && notify.value) {
                if (villagers.value && v != pv) chat("villagers " + pv + " -> " + v);
                if (farm.value && f != pf) chat("farm animals " + pf + " -> " + f);
                if (others.value && o != po) chat("other mobs " + po + " -> " + o);
                if (players.value && p != pp) chat("players " + pp + " -> " + p);
            }
        }
        if (!statsOn.value) { hud(); return; }
        List<String> l = new ArrayList<>();
        if (villagers.value) l.add("Villagers " + v + " (" + sign(v - pv) + ") max " + maxV);
        if (farm.value) l.add("Farm animals " + f + " (" + sign(f - pf) + ") max " + maxF);
        if (others.value) l.add("Other mobs " + o + " (" + sign(o - po) + ") max " + maxO);
        if (players.value) l.add("Players " + p + " (" + sign(p - pp) + ") max " + maxP);
        hud(l.toArray(new String[0]));
    }

    private static String sign(int d) { return d > 0 ? "+" + d : String.valueOf(d); }
}
