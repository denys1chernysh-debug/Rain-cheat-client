package com.rain.modules;

import com.rain.module.*;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import java.util.ArrayList;
import java.util.List;

/** Placement practice assistant: lists valid crystal spots. Does not place anything. */
public class AutoCrystal extends Module {
    private final Setting<Double> range = num("Placement range", 4.5, 2, 6);
    private final Setting<Boolean> onlyHolding = bool("Only when holding crystal", false);
    private final Setting<Boolean> indicators = bool("Visual indicators", true);
    private final Setting<Boolean> notify = bool("Placement notifications", false);
    private int tick, lastCount = -1;
    private List<BlockPos> spots = new ArrayList<>();

    public AutoCrystal() {
        super("Auto Crystal", "Finds valid obsidian/bedrock crystal spots in range (2 free blocks above, no entity) and shows the nearest. Does not place crystals.", Category.CRYSTAL_MACE);
    }

    @Override protected void onTick() {
        boolean holding = mc.player.getMainHandItem().is(Items.END_CRYSTAL) || mc.player.getOffhandItem().is(Items.END_CRYSTAL);
        if (onlyHolding.value && !holding) { hud(); return; }
        if (tick++ % 5 == 0) {
            List<BlockPos> found = new ArrayList<>();
            int r = (int) Math.ceil(range.value);
            BlockPos c = mc.player.blockPosition();
            for (BlockPos p : BlockPos.betweenClosed(c.offset(-r, -r, -r), c.offset(r, r, r))) {
                if (p.distToCenterSqr(mc.player.getEyePosition()) > range.value * range.value) continue;
                var s = mc.level.getBlockState(p);
                if (!s.is(Blocks.OBSIDIAN) && !s.is(Blocks.BEDROCK)) continue;
                BlockPos a = p.above();
                if (!mc.level.getBlockState(a).isAir() || !mc.level.getBlockState(a.above()).isAir()) continue;
                if (!mc.level.getEntities((net.minecraft.world.entity.Entity) null, new AABB(a)).isEmpty()) continue;
                found.add(p.immutable());
            }
            found.sort((x, y) -> Double.compare(x.distToCenterSqr(mc.player.position()), y.distToCenterSqr(mc.player.position())));
            spots = found;
            if (notify.value && found.size() != lastCount && !found.isEmpty()) chat(found.size() + " valid crystal spot(s) in range");
            lastCount = found.size();
        }
        if (!indicators.value) { hud(); return; }
        List<String> l = new ArrayList<>();
        l.add("Valid spots: " + spots.size() + (holding ? " | crystal ready" : " | no crystal held"));
        for (int i = 0; i < Math.min(3, spots.size()); i++) {
            BlockPos p = spots.get(i);
            l.add("  " + p.getX() + " " + p.getY() + " " + p.getZ() + " (" + Targeting.d(Math.sqrt(p.distToCenterSqr(mc.player.position()))) + "m)");
        }
        l.add("Attack cooldown " + (int) (mc.player.getAttackStrengthScale(0f) * 100) + "%");
        hud(l.toArray(new String[0]));
    }
}
