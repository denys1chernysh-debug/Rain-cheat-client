package com.rain.modules;

import com.rain.module.*;
import net.minecraft.core.Holder;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.phys.EntityHitResult;
import java.util.ArrayList;
import java.util.List;

/** Weapon selection advisor. Recommends a hotbar slot; never switches for you. */
public class BreachSwap extends Module {
    private final Setting<Boolean> detect = bool("Weapon detection", true);
    private final Setting<Boolean> enchants = bool("Enchantment display", true);
    private final Setting<Boolean> notify = bool("Notifications", false);
    private int lastSlot = -1, switches, lastRec = -1;

    public BreachSwap() {
        super("Breach Swap", "Scans your hotbar for swords, axes and maces, reads mace enchantments (Breach, Density, Wind Burst) and recommends a weapon. Advice only.", Category.CRYSTAL_MACE);
    }

    private static String kind(ItemStack s) {
        if (s.is(Items.MACE)) return "Mace";
        if (s.is(ItemTags.SWORDS)) return "Sword";
        if (s.is(ItemTags.AXES)) return "Axe";
        return null;
    }

    @Override protected void onTick() {
        int sel = mc.player.getInventory().getSelectedSlot();
        if (lastSlot != -1 && sel != lastSlot) switches++;
        lastSlot = sel;
        int mace = -1, sword = -1, axe = -1;
        List<String> l = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getItem(i);
            String k = kind(s);
            if (k == null) continue;
            if (k.equals("Mace") && mace < 0) mace = i; else if (k.equals("Sword") && sword < 0) sword = i; else if (k.equals("Axe") && axe < 0) axe = i;
            if (detect.value) {
                StringBuilder sb = new StringBuilder("Slot " + (i + 1) + ": " + k);
                if (enchants.value) {
                    ItemEnchantments en = s.getEnchantments();
                    for (Holder<Enchantment> h : en.keySet()) sb.append(" ").append(h.getRegisteredName().replace("minecraft:", "")).append(" ").append(en.getLevel(h));
                }
                l.add(sb.toString());
            }
        }
        boolean heavyArmor = mc.hitResult instanceof EntityHitResult ehr && ehr.getEntity() instanceof LivingEntity le && le.getArmorValue() >= 10;
        int rec = (mace >= 0 && (mc.player.fallDistance > 1.5 || heavyArmor)) ? mace : sword >= 0 ? sword : axe >= 0 ? axe : mace;
        if (rec >= 0) l.add("Recommended: slot " + (rec + 1) + (rec == sel ? " (selected)" : "") + (mc.player.fallDistance > 1.5 && rec == mace ? " - falling, smash!" : ""));
        else l.add("No weapons in hotbar");
        l.add("Hotbar switches: " + switches);
        if (notify.value && rec != lastRec && rec >= 0 && rec != sel) chat("recommend slot " + (rec + 1));
        lastRec = rec;
        hud(l.toArray(new String[0]));
    }
}
