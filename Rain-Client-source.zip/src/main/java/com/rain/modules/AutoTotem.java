package com.rain.modules;

import com.rain.module.*;
import net.minecraft.world.item.Items;

/** Offhand monitor. Notifies only; it never moves items for you. */
public class AutoTotem extends Module {
    private final Setting<Boolean> notify = bool("Refill notifications", true);
    private final Setting<Boolean> invStatus = bool("Inventory status", true);
    private final Setting<Boolean> offhandHud = bool("Offhand HUD", true);
    private final Setting<Double> cooldown = num("Notification cooldown (ticks)", 100, 20, 600);
    private int wait;
    private boolean wasOk = true;

    public AutoTotem() {
        super("Auto Totem", "Monitors your offhand and tells you when it lacks a Totem of Undying while you carry spares. Notifies only; moves nothing.", Category.CRYSTAL_MACE);
    }

    @Override protected void onTick() {
        boolean off = mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING);
        int count = 0;
        for (int i = 0; i < 36; i++) if (mc.player.getInventory().getItem(i).is(Items.TOTEM_OF_UNDYING)) count++;
        if (wait > 0) wait--;
        if (!off && count > 0 && notify.value && wait == 0 && (wasOk || true)) { chat("offhand empty, " + count + " totem(s) in inventory"); wait = cooldown.value.intValue(); }
        wasOk = off;
        java.util.List<String> l = new java.util.ArrayList<>();
        if (offhandHud.value) l.add("Offhand: " + (off ? "TOTEM" : mc.player.getOffhandItem().isEmpty() ? "EMPTY" : "other item"));
        if (invStatus.value) l.add("Spare totems in inventory: " + count);
        hud(l.toArray(new String[0]));
    }
}
