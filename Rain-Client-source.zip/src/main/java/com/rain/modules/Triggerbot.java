package com.rain.modules;

import com.rain.module.*;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/** Timing assistant: shows when an attack WOULD be triggered. It does not attack for you. */
public class Triggerbot extends Module {
    private final Setting<Double> delay = num("Delay (ticks)", 2, 0, 10);
    private final Setting<Double> range = num("Range", 3.0, 1, 6);
    private final Setting<Boolean> players = bool("Target players", true);
    private final Setting<Boolean> mobs = bool("Target mobs", true);
    private final Setting<Boolean> needCooldown = bool("Require attack cooldown", true);
    private final Setting<Boolean> indicator = bool("Visual indicator", true);
    private int onTarget;

    public Triggerbot() {
        super("Triggerbot", "Detects eligible targets under your crosshair and shows when an attack would trigger. Display only; you still click.", Category.COMBAT);
    }

    @Override protected void onTick() {
        HitResult hr = mc.hitResult;
        if (hr instanceof EntityHitResult ehr && ehr.getEntity() instanceof LivingEntity le
                && ((players.value && le instanceof Player) || (mobs.value && le instanceof Mob))) {
            double dist = mc.player.getEyePosition().distanceTo(ehr.getLocation());
            if (dist <= range.value) {
                onTarget++;
                float cd = mc.player.getAttackStrengthScale(0f);
                boolean ready = onTarget >= delay.value && (!needCooldown.value || cd >= 0.9f);
                if (indicator.value) hud(ready ? ">>> ATTACK NOW <<<" : "Target in sights " + onTarget + "/" + delay.value.intValue(),
                        le.getName().getString() + " " + Targeting.d(dist) + "m, cooldown " + (int) (cd * 100) + "%");
                else hud();
                return;
            }
        }
        onTarget = 0;
        hud(indicator.value ? "No target under crosshair" : "");
    }
}
