package com.rain.modules;

import com.rain.module.*;

/** Sprint-reset practice tracker. Observes your inputs; never presses keys. */
public class WTap extends Module {
    private final Setting<Double> window = num("Timing window (ticks)", 6, 1, 20);
    private final Setting<Boolean> feedback = bool("Visual feedback", true);
    private final Setting<Boolean> stats = bool("Statistics", true);

    private boolean wasAttack, wasSprint, sprintedAtAttack, counted;
    private int sinceAttack = 999, dropTick = -1, success, attempts;
    private String last = "-";

    public WTap() {
        super("W-Tap", "Sprint-reset timing tracker: counts how often you drop and re-gain sprint inside the window after an attack.", Category.COMBAT);
    }

    @Override protected void onEnable() { success = 0; attempts = 0; sinceAttack = 999; last = "-"; }

    @Override protected void onTick() {
        boolean atk = mc.options.keyAttack.isDown(), spr = mc.player.isSprinting();
        if (atk && !wasAttack) { sinceAttack = 0; sprintedAtAttack = spr; dropTick = -1; counted = false; attempts++; }
        else sinceAttack++;
        if (sinceAttack <= window.value && sprintedAtAttack && !counted) {
            if (!spr && wasSprint && dropTick < 0) dropTick = sinceAttack;
            if (spr && dropTick >= 0) { success++; counted = true; last = "reset in " + sinceAttack + " ticks"; }
        }
        wasAttack = atk; wasSprint = spr;
        java.util.List<String> l = new java.util.ArrayList<>();
        if (feedback.value) l.add("Sprint: " + (spr ? "ON" : "off") + " | last: " + last);
        if (stats.value) l.add("Successful resets " + success + "/" + attempts);
        hud(l.toArray(new String[0]));
    }
}
