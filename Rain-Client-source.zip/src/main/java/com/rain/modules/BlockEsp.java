package com.rain.modules;

import com.rain.module.*;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import java.util.*;

/** Lists selected block types found in the world data your client has (honors server anti-xray). */
public class BlockEsp extends Module {
    private final LinkedHashMap<Setting<Boolean>, Block[]> choices = new LinkedHashMap<>();
    private final Setting<Double> range = num("Range", 16, 4, 32);
    private final Setting<Double> maxLines = num("Max list lines", 8, 1, 15);
    private int tick;
    private List<String> cache = new ArrayList<>();

    public BlockEsp() {
        super("Block ESP", "Finds selected blocks (ores, spawners, debris, geodes) in loaded world data and lists name, coordinates and distance. Cannot see through server anti-xray.", Category.BASE_HUNTING);
        choices.put(bool("Diamond ore", true), new Block[]{Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE});
        choices.put(bool("Ancient debris", true), new Block[]{Blocks.ANCIENT_DEBRIS});
        choices.put(bool("Emerald ore", false), new Block[]{Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE});
        choices.put(bool("Gold ore", false), new Block[]{Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.NETHER_GOLD_ORE});
        choices.put(bool("Iron ore", false), new Block[]{Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE});
        choices.put(bool("Spawner", true), new Block[]{Blocks.SPAWNER});
        choices.put(bool("Budding amethyst", false), new Block[]{Blocks.BUDDING_AMETHYST});
    }

    @Override protected void onTick() {
        if (tick++ % 20 == 0) {
            Set<Block> want = new HashSet<>();
            for (var e : choices.entrySet()) if (e.getKey().value) want.addAll(Arrays.asList(e.getValue()));
            List<Object[]> found = new ArrayList<>();
            int r = range.value.intValue();
            BlockPos c = mc.player.blockPosition();
            if (!want.isEmpty()) for (BlockPos p : BlockPos.betweenClosed(c.offset(-r, -r, -r), c.offset(r, r, r))) {
                var s = mc.level.getBlockState(p);
                if (!want.contains(s.getBlock())) continue;
                found.add(new Object[]{Math.sqrt(p.distToCenterSqr(mc.player.position())), s.getBlock().getName().getString(), p.immutable()});
            }
            found.sort(Comparator.comparingDouble(o -> (double) o[0]));
            List<String> out = new ArrayList<>();
            out.add(found.size() + " block(s) found" + (want.isEmpty() ? " (nothing selected)" : ""));
            for (int i = 0; i < Math.min(maxLines.value.intValue(), found.size()); i++) {
                Object[] o = found.get(i); BlockPos p = (BlockPos) o[2];
                out.add(o[1] + " " + p.getX() + " " + p.getY() + " " + p.getZ() + " (" + Targeting.d((double) o[0]) + "m)");
            }
            cache = out;
        }
        hud(cache.toArray(new String[0]));
    }
}
