package com.rain.modules;

import com.rain.module.*;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import java.util.*;

/** Tracks crystal spawn/removal timing and your ping. Analysis only. */
public class CrystalOptimizer extends Module {
    private final Setting<Boolean> timing = bool("Timing display", true);
    private final Setting<Boolean> latencyGraph = bool("Latency graph", true);
    private final Setting<Boolean> notify = bool("Notifications", false);

    private final Map<Integer, Long> seen = new HashMap<>();
    private final ArrayDeque<Double> lifetimes = new ArrayDeque<>();
    private final ArrayDeque<Integer> pings = new ArrayDeque<>();
    private int placed, destroyed, tick;
    private double lastLife;

    public CrystalOptimizer() {
        super("Crystal Optimizer", "Measures how long crystals live before being destroyed, counts placements/destructions and graphs your latency.", Category.CRYSTAL_MACE);
    }

    @Override protected void onEnable() { seen.clear(); lifetimes.clear(); pings.clear(); placed = 0; destroyed = 0; }

    private int ping() {
        var conn = mc.getConnection();
        if (conn == null) return 0;
        var info = conn.getPlayerInfo(mc.player.getUUID());
        return info == null ? 0 : info.getLatency();
    }

    @Override protected void onTick() {
        long now = System.nanoTime();
        Set<Integer> cur = new HashSet<>();
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof EndCrystal)) continue;
            cur.add(e.getId());
            if (!seen.containsKey(e.getId())) { seen.put(e.getId(), now); placed++; }
        }
        Iterator<Map.Entry<Integer, Long>> it = seen.entrySet().iterator();
        while (it.hasNext()) {
            var en = it.next();
            if (!cur.contains(en.getKey())) {
                lastLife = (now - en.getValue()) / 1_000_000.0;
                lifetimes.addLast(lastLife); if (lifetimes.size() > 20) lifetimes.pollFirst();
                destroyed++; it.remove();
                if (notify.value) chat("crystal gone after " + (int) lastLife + "ms (ping " + ping() + "ms)");
            }
        }
        if (tick++ % 10 == 0) { pings.addLast(ping()); if (pings.size() > 30) pings.pollFirst(); }
        List<String> l = new ArrayList<>();
        if (timing.value) {
            double avg = lifetimes.stream().mapToDouble(d -> d).average().orElse(0);
            l.add("Crystals seen " + placed + " | removed " + destroyed + " | active " + seen.size());
            l.add("Last life " + (int) lastLife + "ms | avg " + (int) avg + "ms | ping " + ping() + "ms");
        }
        if (latencyGraph.value) {
            StringBuilder g = new StringBuilder("Ping [");
            for (int p : pings) g.append(" .:-=+*#".charAt(Math.max(0, Math.min(7, p / 40))));
            l.add(g.append("]").toString());
        }
        hud(l.toArray(new String[0]));
    }
}
