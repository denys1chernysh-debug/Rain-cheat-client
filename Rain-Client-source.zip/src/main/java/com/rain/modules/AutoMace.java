package com.rain.modules;

import com.rain.module.*;
import net.minecraft.world.item.Items;

/** Mace timing assistant: fall tracking and estimated smash bonus. Never attacks for you. */
public class AutoMace extends Module {
    private final Setting<Boolean> fallIndicator = bool("Fall indicator", true);
    private final Setting<Boolean> timing = bool("Timing display", true);
    private final Setting<Boolean> maceHud = bool("Mace HUD", true);
    private double maxFall;

    public AutoMace() {
        super("Auto Mace", "Detects a held mace, tracks airborne fall distance and shows the estimated smash-attack bonus and cooldown. Display only.", Category.CRYSTAL_MACE);
    }

    @Override protected void onTick() {
        boolean mace = mc.player.getMainHandItem().is(Items.MACE);
        double fd = mc.player.fallDistance;
        boolean air = !mc.player.onGround();
        if (air) maxFall = Math.max(maxFall, fd); else if (fd == 0) { /* keep last max for display */ }
        java.util.List<String> l = new java.util.ArrayList<>();
        if (maceHud.value) l.add(mace ? "Mace: HELD" : "Mace: not held");
        if (fallIndicator.value) l.add((air ? "Airborne" : "Grounded") + " | fall " + Targeting.d(fd) + " blocks | peak " + Targeting.d(maxFall));
        if (timing.value) {
            double bonus = Math.min(fd, 3) * 4 + Math.max(0, Math.min(fd - 3, 5)) * 2 + Math.max(0, fd - 8);
            boolean smash = fd > 1.5;
            l.add((smash ? "Smash attack possible" : "Fall > 1.5 needed") + " | est. bonus dmg ~" + Targeting.d(bonus) + " | cooldown " + (int) (mc.player.getAttackStrengthScale(0f) * 100) + "%");
        }
        hud(l.toArray(new String[0]));
    }
}
