package com.rain.modules;

import com.rain.module.*;
import java.util.ArrayDeque;

/** CPS trainer: measures YOUR real attack-key clicks. It does not click for you. */
public class AutoClicker extends Module {
    private final Setting<Double> targetCps = num("Target CPS", 10, 1, 30);
    private final Setting<Double> minCps = num("Minimum CPS", 6, 1, 30);
    private final Setting<Double> maxCps = num("Maximum CPS", 14, 1, 30);
    private final Setting<Double> randomization = num("Randomization (+/- CPS)", 2, 0, 10);
    private final Setting<Boolean> display = bool("CPS display", true);

    private final ArrayDeque<Long> clicks = new ArrayDeque<>();
    private boolean wasDown;
    private int peak, total, goal;
    private long sumIntervalMs, intervals, lastClick;

    public AutoClicker() {
        super("Auto Clicker", "CPS test and click trainer: measures your clicks, intervals and stats against a randomized practice target. Does not click for you.", Category.COMBAT);
    }

    @Override protected void onEnable() { clicks.clear(); peak = 0; total = 0; sumIntervalMs = 0; intervals = 0; lastClick = 0; rollGoal(); }

    private void rollGoal() {
        double r = (Math.random() * 2 - 1) * randomization.value;
        goal = (int) Math.round(Math.max(minCps.value, Math.min(maxCps.value, targetCps.value + r)));
    }

    @Override protected void onTick() {
        long now = System.currentTimeMillis();
        boolean down = mc.options.keyAttack.isDown();
        if (down && !wasDown) {
            clicks.add(now); total++;
            if (lastClick != 0 && now - lastClick < 2000) { sumIntervalMs += now - lastClick; intervals++; }
            lastClick = now; rollGoal();
        }
        wasDown = down;
        while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) clicks.pollFirst();
        int cps = clicks.size();
        peak = Math.max(peak, cps);
        if (!display.value) { hud(); return; }
        String state = cps == 0 ? "" : cps < minCps.value ? " (below min)" : cps > maxCps.value ? " (above max)" : " (in range)";
        hud("CPS " + cps + state + " | goal " + goal,
            "Peak " + peak + " | clicks " + total + " | avg interval " + (intervals == 0 ? "-" : (sumIntervalMs / intervals) + "ms"));
    }
}
