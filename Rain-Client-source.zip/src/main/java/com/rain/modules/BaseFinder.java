package com.rain.modules;

import com.rain.module.*;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import java.util.*;

/** Heuristic chunk analysis using only data the client actually has. Not proof of a base. */
public class BaseFinder extends Module {
    public record Det(int cx, int cz, int prob, List<String> reasons, boolean geode) {}
    public static final Map<Long, Det> results = new HashMap<>();

    private final Setting<Double> minProb = num("Minimum probability %", 30, 5, 95);
    private final Setting<Double> radius = num("Scan radius (chunks)", 6, 2, 12);
    private final Setting<Double> interval = num("Scan interval (ticks)", 4, 1, 100);
    private final Setting<Boolean> notifications = bool("Notifications", true);
    private final Setting<Boolean> hudOn = bool("HUD list with reasons", true);

    private final List<int[]> queue = new ArrayList<>();
    private int cursor, tick, lastPcx = Integer.MIN_VALUE, lastPcz;
    private final Set<Long> notified = new HashSet<>();

    public BaseFinder() {
        super("Base Finder", "Scores loaded chunks for storage blocks and player-style blocks and explains every score. Natural structures (villages, mineshafts) cause false positives.", Category.BASE_HUNTING);
    }

    public static long key(int cx, int cz) { return ((long) cx << 32) | (cz & 0xffffffffL); }

    @Override protected void onEnable() { results.clear(); notified.clear(); queue.clear(); cursor = 0; }

    static boolean isArtificial(BlockState s) {
        return s.is(BlockTags.PLANKS) || s.is(Blocks.COBBLESTONE) || s.is(Blocks.STONE_BRICKS) || s.is(Blocks.BRICKS)
                || s.is(Blocks.GLASS) || s.is(Blocks.GLASS_PANE) || s.is(Blocks.TORCH) || s.is(Blocks.CRAFTING_TABLE)
                || s.is(Blocks.BOOKSHELF) || s.is(BlockTags.BEDS) || s.is(BlockTags.DOORS) || s.is(BlockTags.WOOL);
    }

    private void rebuild(int pcx, int pcz) {
        queue.clear(); int r = radius.value.intValue();
        for (int x = -r; x <= r; x++) for (int z = -r; z <= r; z++) queue.add(new int[]{pcx + x, pcz + z});
        queue.sort(Comparator.comparingInt(a -> (a[0] - pcx) * (a[0] - pcx) + (a[1] - pcz) * (a[1] - pcz)));
        cursor = 0; lastPcx = pcx; lastPcz = pcz;
    }

    @Override protected void onTick() {
        int pcx = mc.player.blockPosition().getX() >> 4, pcz = mc.player.blockPosition().getZ() >> 4;
        if (queue.isEmpty() || Math.abs(pcx - lastPcx) > 2 || Math.abs(pcz - lastPcz) > 2) rebuild(pcx, pcz);
        if (tick++ % Math.max(1, interval.value.intValue()) == 0 && !queue.isEmpty()) {
            for (int tries = 0; tries < queue.size(); tries++) {
                int[] c = queue.get(cursor++ % queue.size());
                if (mc.level.hasChunk(c[0], c[1])) { scan(c[0], c[1]); break; }
            }
            if (cursor >= queue.size() * 4) cursor = 0;
        }
        if (!hudOn.value) { hud(); return; }
        List<Det> top = new ArrayList<>(results.values());
        top.removeIf(d -> d.prob < minProb.value);
        top.sort((a, b) -> Integer.compare(b.prob, a.prob));
        List<String> l = new ArrayList<>();
        l.add("Scanned chunks: " + results.size() + " | candidates: " + top.size());
        for (int i = 0; i < Math.min(2, top.size()); i++) {
            Det d = top.get(i);
            l.add("[" + d.prob + "%] chunk " + d.cx + "," + d.cz + " (~" + (d.cx * 16 + 8) + ", " + (d.cz * 16 + 8) + ")" + (d.geode ? " geode nearby" : ""));
            for (String r : d.reasons) l.add("   - " + r);
        }
        hud(l.toArray(new String[0]));
    }

    private void scan(int cx, int cz) {
        LevelChunk c = mc.level.getChunk(cx, cz);
        int chests = 0, barrels = 0, shulkers = 0, hoppers = 0, furnaces = 0, spawners = 0;
        for (BlockEntity be : c.getBlockEntities().values()) {
            if (be instanceof ChestBlockEntity) chests++;
            else if (be instanceof BarrelBlockEntity) barrels++;
            else if (be instanceof ShulkerBoxBlockEntity) shulkers++;
            else if (be instanceof HopperBlockEntity) hoppers++;
            else if (be instanceof AbstractFurnaceBlockEntity) furnaces++;
            else if (be instanceof SpawnerBlockEntity) spawners++;
        }
        int artificial = 0; boolean geode = false;
        for (LevelChunkSection sec : c.getSections()) {
            if (sec.hasOnlyAir()) continue;
            if (sec.maybeHas(s -> s.is(Blocks.BUDDING_AMETHYST))) geode = true;
            if (!sec.maybeHas(BaseFinder::isArtificial)) continue;
            for (int x = 0; x < 16; x++) for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++)
                if (isArtificial(sec.getBlockState(x, y, z))) artificial++;
        }
        List<String> why = new ArrayList<>(); int score = 0;
        if (chests > 0) { int p = Math.min(36, chests * 12); score += p; why.add(chests + " chest(s) (+" + p + ")"); }
        if (shulkers > 0) { int p = Math.min(40, shulkers * 20); score += p; why.add(shulkers + " shulker box(es) (+" + p + ")"); }
        if (barrels > 0) { int p = Math.min(16, barrels * 8); score += p; why.add(barrels + " barrel(s) (+" + p + ")"); }
        if (hoppers > 0) { int p = Math.min(16, hoppers * 8); score += p; why.add(hoppers + " hopper(s) (+" + p + ")"); }
        if (furnaces > 0) { int p = Math.min(8, furnaces * 4); score += p; why.add(furnaces + " furnace(s) (+" + p + ")"); }
        if (artificial > 0) { int p = Math.min(40, artificial / 3); if (p > 0) { score += p; why.add(artificial + " player-style blocks (planks/cobble/glass/etc) (+" + p + ")"); } }
        if (spawners > 0) why.add(spawners + " spawner(s) (dungeon/spawner area, not scored)");
        long k = key(cx, cz);
        score = Math.min(99, score);
        if (score > 0 || spawners > 0) {
            Det d = new Det(cx, cz, score, why, geode);
            results.put(k, d);
            if (notifications.value && score >= minProb.value && notified.add(k)) chat("possible base at chunk " + cx + "," + cz + " (" + score + "%)");
        } else results.remove(k);
    }
}
