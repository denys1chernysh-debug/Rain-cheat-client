package com.rain.modules;

import com.rain.module.*;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import java.util.ArrayList;
import java.util.List;

/** Respawn anchor practice guide. Reads charges and shows the correct sequence; never interacts for you. */
public class AnchorMacro extends Module {
    private final Setting<Double> range = num("Scan range", 6, 2, 10);
    private final Setting<Boolean> charges = bool("Charge indicators", true);
    private final Setting<Boolean> sequence = bool("Interaction sequence", true);
    private final Setting<Boolean> timing = bool("Timing display", true);
    private BlockPos anchor;
    private int charge = -1, tick, sinceChange;

    public AnchorMacro() {
        super("Anchor Macro", "Finds the nearest respawn anchor, shows glowstone charges, the correct charge/detonate sequence and step timing. Practice only.", Category.CRYSTAL_MACE);
    }

    @Override protected void onTick() {
        if (tick++ % 5 == 0) {
            BlockPos best = null; double bd = Double.MAX_VALUE;
            int r = (int) Math.ceil(range.value);
            BlockPos c = mc.player.blockPosition();
            for (BlockPos p : BlockPos.betweenClosed(c.offset(-r, -r, -r), c.offset(r, r, r))) {
                if (!mc.level.getBlockState(p).is(Blocks.RESPAWN_ANCHOR)) continue;
                double d = p.distToCenterSqr(mc.player.position());
                if (d < bd && d <= range.value * range.value) { bd = d; best = p.immutable(); }
            }
            anchor = best;
        }
        if (anchor == null) { charge = -1; hud("No respawn anchor in range"); return; }
        var st = mc.level.getBlockState(anchor);
        if (!st.is(Blocks.RESPAWN_ANCHOR)) { anchor = null; hud(); return; }
        int ch = st.getValue(RespawnAnchorBlock.CHARGE);
        if (ch != charge) { charge = ch; sinceChange = 0; } else sinceChange++;
        boolean glow = mc.player.getMainHandItem().is(Items.GLOWSTONE) || mc.player.getOffhandItem().is(Items.GLOWSTONE);
        List<String> l = new ArrayList<>();
        if (charges.value) l.add("Anchor " + anchor.getX() + " " + anchor.getY() + " " + anchor.getZ() + " charge " + "#".repeat(ch) + "-".repeat(4 - ch) + " " + ch + "/4");
        if (sequence.value) {
            String step = ch < 1 ? (glow ? "Step 1: right-click anchor to charge" : "Step 1: hold glowstone")
                    : !glow ? "Step 3: right-click with non-glowstone to detonate (outside the Nether it explodes!)"
                    : ch < 4 ? "Step 2: charged " + ch + ", add more or swap item" : "Fully charged: swap item, then detonate";
            l.add(step);
        }
        if (timing.value) l.add("Ticks since last charge change: " + sinceChange);
        hud(l.toArray(new String[0]));
    }
}
