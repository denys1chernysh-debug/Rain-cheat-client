package com.rain.modules;

import com.rain.module.*;
import net.minecraft.world.level.block.entity.*;
import java.util.*;

/** Lists loaded storage block entities. Only uses data the server actually sent to your client. */
public class StorageEsp extends Module {
    private final Setting<Boolean> chests = bool("Chests", true);
    private final Setting<Boolean> shulkers = bool("Shulker boxes", true);
    private final Setting<Boolean> barrels = bool("Barrels", true);
    private final Setting<Boolean> hoppers = bool("Hoppers", true);
    private final Setting<Boolean> spawners = bool("Spawners", true);
    private final Setting<Double> range = num("Range", 64, 8, 256);
    private final Setting<Boolean> labels = bool("Labels", true);
    private final Setting<Boolean> distance = bool("Distance display", true);
    private final Setting<Double> maxLines = num("Max list lines", 8, 1, 15);
    private int tick;
    private List<String> cache = new ArrayList<>();

    public StorageEsp() {
        super("Storage ESP", "Lists loaded chests, shulkers, barrels, hoppers and spawners near you with coordinates and distance. Never reveals server-hidden data.", Category.BASE_HUNTING);
    }

    private String type(BlockEntity be) {
        if (be instanceof ChestBlockEntity && chests.value) return "Chest";
        if (be instanceof ShulkerBoxBlockEntity && shulkers.value) return "Shulker";
        if (be instanceof BarrelBlockEntity && barrels.value) return "Barrel";
        if (be instanceof HopperBlockEntity && hoppers.value) return "Hopper";
        if (be instanceof SpawnerBlockEntity && spawners.value) return "Spawner";
        return null;
    }

    @Override protected void onTick() {
        if (tick++ % 10 == 0) {
            int pcx = mc.player.blockPosition().getX() >> 4, pcz = mc.player.blockPosition().getZ() >> 4;
            int cr = (int) Math.ceil(range.value / 16.0);
            List<Object[]> found = new ArrayList<>();
            Map<String, Integer> counts = new TreeMap<>();
            for (int x = -cr; x <= cr; x++) for (int z = -cr; z <= cr; z++) {
                if (!mc.level.hasChunk(pcx + x, pcz + z)) continue;
                for (BlockEntity be : mc.level.getChunk(pcx + x, pcz + z).getBlockEntities().values()) {
                    String t = type(be); if (t == null) continue;
                    double d = Math.sqrt(be.getBlockPos().distToCenterSqr(mc.player.position()));
                    if (d > range.value) continue;
                    found.add(new Object[]{d, t, be.getBlockPos()});
                    counts.merge(t, 1, Integer::sum);
                }
            }
            found.sort(Comparator.comparingDouble(o -> (double) o[0]));
            List<String> out = new ArrayList<>();
            out.add(counts.isEmpty() ? "No storage in range" : counts.toString());
            for (int i = 0; i < Math.min(maxLines.value.intValue(), found.size()); i++) {
                Object[] o = found.get(i); var p = (net.minecraft.core.BlockPos) o[2];
                out.add((labels.value ? o[1] + " " : "") + p.getX() + " " + p.getY() + " " + p.getZ() + (distance.value ? " (" + Targeting.d((double) o[0]) + "m)" : ""));
            }
            cache = out;
        }
        hud(cache.toArray(new String[0]));
    }
}
