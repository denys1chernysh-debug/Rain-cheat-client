package com.rain.modules;

import com.rain.module.*;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;
import java.util.HashSet;
import java.util.Set;

/** Entity highlighting + dimension readout. Uses the client-side glow outline; real boxes: F3+B. */
public class Hitboxes extends Module {
    private final Setting<Double> range = num("Range", 32, 4, 128);
    private final Setting<Boolean> playersOnly = bool("Player-only mode", false);
    private final Setting<Boolean> showDims = bool("Show dimensions", true);
    private final Setting<Boolean> highlightSelected = bool("Highlight crosshair entity", true);
    private Set<Entity> glowed = new HashSet<>();

    public Hitboxes() {
        super("Hitboxes", "Outlines nearby entities (client-side glow) and shows hitbox dimensions of the entity you look at.", Category.COMBAT);
    }

    @Override protected void onDisable() { for (Entity e : glowed) e.setGlowingTag(false); glowed = new HashSet<>(); }

    @Override protected void onTick() {
        Set<Entity> now = new HashSet<>();
        for (Entity e : mc.level.entitiesForRendering()) {
            if (e == mc.player || !(e instanceof LivingEntity)) continue;
            if (playersOnly.value && !(e instanceof Player)) continue;
            if (mc.player.distanceTo(e) > range.value) continue;
            e.setGlowingTag(true); now.add(e);
        }
        for (Entity e : glowed) if (!now.contains(e)) e.setGlowingTag(false);
        glowed = now;
        java.util.List<String> l = new java.util.ArrayList<>();
        l.add("Outlined entities: " + now.size());
        if (mc.hitResult instanceof EntityHitResult ehr && showDims.value) {
            Entity t = ehr.getEntity();
            l.add("Looking at " + t.getName().getString() + ": " + Targeting.d(t.getBbWidth()) + " wide x " + Targeting.d(t.getBbHeight()) + " tall, eye " + Targeting.d(t.getEyeHeight()));
            if (!highlightSelected.value) { /* selection highlight off */ }
        }
        hud(l.toArray(new String[0]));
    }
}
