package com.rain.modules;

import com.rain.module.*;
import net.minecraft.world.phys.Vec3;
import java.util.ArrayDeque;

/** Knockback analysis only. Reads your own movement; cannot change knockback. */
public class Velocity extends Module {
    private final Setting<Boolean> horizontal = bool("Horizontal display", true);
    private final Setting<Boolean> vertical = bool("Vertical display", true);
    private final Setting<Boolean> graph = bool("Graph", true);
    private final Setting<Boolean> stats = bool("Statistics", true);

    private Vec3 prev = Vec3.ZERO;
    private int hits;
    private double lastH, lastV, maxH, sumH;
    private final ArrayDeque<Double> hist = new ArrayDeque<>();

    public Velocity() {
        super("Velocity", "Knockback analysis: shows horizontal/vertical velocity, a speed graph and knockback statistics.", Category.COMBAT);
    }

    @Override protected void onEnable() { prev = mc.player != null ? mc.player.getDeltaMovement() : Vec3.ZERO; hits = 0; maxH = 0; sumH = 0; hist.clear(); }

    @Override protected void onTick() {
        Vec3 v = mc.player.getDeltaMovement();
        double h = Math.sqrt(v.x * v.x + v.z * v.z), ph = Math.sqrt(prev.x * prev.x + prev.z * prev.z);
        if (mc.player.hurtTime == mc.player.hurtDuration - 1 && h - ph > 0.1) {
            hits++; lastH = h; lastV = v.y; maxH = Math.max(maxH, h); sumH += h;
        }
        prev = v;
        hist.addLast(h); if (hist.size() > 40) hist.pollFirst();
        java.util.List<String> l = new java.util.ArrayList<>();
        StringBuilder sb = new StringBuilder();
        if (horizontal.value) sb.append("H ").append(String.format("%.3f", h)).append("  ");
        if (vertical.value) sb.append("V ").append(String.format("%.3f", v.y));
        if (sb.length() > 0) l.add(sb.toString());
        if (graph.value) {
            String chars = " .:-=+*#"; StringBuilder g = new StringBuilder("[");
            for (double d : hist) g.append(chars.charAt((int) Math.max(0, Math.min(7, d / 0.6 * 7))));
            l.add(g.append("]").toString());
        }
        if (stats.value) l.add("KB hits " + hits + " | last H " + Targeting.d3(lastH) + " V " + Targeting.d3(lastV) + " | max H " + Targeting.d3(maxH) + " | avg H " + (hits == 0 ? "-" : Targeting.d3(sumH / hits)));
        hud(l.toArray(new String[0]));
    }
}
