package com.rain.config;

import com.google.gson.*;
import com.rain.module.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;

public class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("rain-client.json"); }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            JsonObject ui = new JsonObject();
            ui.addProperty("interfaceOpacity", UiSettings.interfaceOpacity);
            ui.addProperty("buttonTransparency", UiSettings.buttonTransparency);
            ui.addProperty("backgroundTransparency", UiSettings.backgroundTransparency);
            root.add("ui", ui);
            JsonObject mods = new JsonObject();
            for (Module m : ModuleManager.all()) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.isEnabled());
                o.addProperty("keybind", m.keybind);
                JsonObject st = new JsonObject();
                for (Setting<?> s : m.getSettings()) {
                    if (s.value instanceof Boolean) st.addProperty(s.name, (Boolean) s.value);
                    else if (s.value instanceof Number) st.addProperty(s.name, (Number) s.value);
                    else if (s.value instanceof String) st.addProperty(s.name, (String) s.value);
                }
                o.add("settings", st);
                mods.add(m.name, o);
            }
            root.add("modules", mods);
            Files.writeString(file(), GSON.toJson(root));
        } catch (Throwable t) { System.err.println("[Rain] config save failed: " + t); }
    }

    public static void load() {
        try {
            if (!Files.exists(file())) return;
            JsonObject root = JsonParser.parseString(Files.readString(file())).getAsJsonObject();
            if (root.has("ui")) {
                JsonObject ui = root.getAsJsonObject("ui");
                if (ui.has("interfaceOpacity")) UiSettings.interfaceOpacity = Math.max(10, Math.min(100, ui.get("interfaceOpacity").getAsDouble()));
                if (ui.has("buttonTransparency")) UiSettings.buttonTransparency = Math.max(0, Math.min(100, ui.get("buttonTransparency").getAsDouble()));
                if (ui.has("backgroundTransparency")) UiSettings.backgroundTransparency = Math.max(0, Math.min(100, ui.get("backgroundTransparency").getAsDouble()));
            }
            JsonObject mods = root.has("modules") ? root.getAsJsonObject("modules") : new JsonObject();
            for (Module m : ModuleManager.all()) {
                if (!mods.has(m.name)) continue;
                JsonObject o = mods.getAsJsonObject(m.name);
                if (o.has("keybind")) m.keybind = o.get("keybind").getAsInt();
                if (o.has("settings")) {
                    JsonObject st = o.getAsJsonObject("settings");
                    for (Setting<?> s : m.getSettings()) {
                        if (!st.has(s.name)) continue;
                        JsonPrimitive p = st.get(s.name).getAsJsonPrimitive();
                        if (p.isBoolean()) s.set(p.getAsBoolean());
                        else if (p.isString()) s.set(p.getAsString());
                        else s.set(p.getAsDouble());
                    }
                }
                if (o.has("enabled") && o.get("enabled").getAsBoolean()) m.setEnabled(true);
            }
        } catch (Throwable t) { System.err.println("[Rain] config load failed: " + t); }
    }
}
