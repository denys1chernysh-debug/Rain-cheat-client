package com.rain.config;

/** Three independent controls. Changing one never touches the others. */
public class UiSettings {
    public static double interfaceOpacity = 90;        // 10-100
    public static double buttonTransparency = 70;      // 0-100
    public static double backgroundTransparency = 40;  // 0-100

    public static void resetAll() { interfaceOpacity = 90; buttonTransparency = 70; backgroundTransparency = 40; ConfigManager.save(); }
}
