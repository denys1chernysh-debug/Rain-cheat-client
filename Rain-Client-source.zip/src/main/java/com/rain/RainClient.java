package com.rain;

import com.rain.config.ConfigManager;
import com.rain.gui.HudManager;
import com.rain.gui.RainScreen;
import com.rain.module.ModuleManager;
import com.rain.modules.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public class RainClient implements ClientModInitializer {
    private boolean wasShift;

    @Override public void onInitializeClient() {
        // Combat
        ModuleManager.register(new AimAssist());
        ModuleManager.register(new SilentAim());
        ModuleManager.register(new Triggerbot());
        ModuleManager.register(new AutoClicker());
        ModuleManager.register(new WTap());
        ModuleManager.register(new Velocity());
        ModuleManager.register(new Hitboxes());
        // Crystal & Mace
        ModuleManager.register(new AutoCrystal());
        ModuleManager.register(new CrystalOptimizer());
        ModuleManager.register(new AnchorMacro());
        ModuleManager.register(new AutoTotem());
        ModuleManager.register(new AutoMace());
        ModuleManager.register(new BreachSwap());
        ModuleManager.register(new WindPearl());
        // Base Hunting
        ModuleManager.register(new BaseFinder());
        ModuleManager.register(new AutoBaseHunt());
        ModuleManager.register(new StorageEsp());
        ModuleManager.register(new BlockEsp());
        ModuleManager.register(new ActivityTrackers());

        ConfigManager.load();

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            long window = mc.getWindow().handle();
            boolean shift = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
            if (shift && !wasShift && mc.screen == null && mc.player != null) mc.setScreen(new RainScreen());
            wasShift = shift;
            ModuleManager.pollKeys(window, mc.screen == null);
            ModuleManager.tick();
        });

        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("rain", "hud"), (graphics, tickCounter) -> HudManager.render(graphics));
        Runtime.getRuntime().addShutdownHook(new Thread(ConfigManager::save));
    }
}
