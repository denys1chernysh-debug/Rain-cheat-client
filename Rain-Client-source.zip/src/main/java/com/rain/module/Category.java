package com.rain.module;

public enum Category {
    COMBAT("Combat", "Enhance your PvP practice with combat tools."),
    CRYSTAL_MACE("Crystal & Mace", "Crystal, anchor, totem and mace timing assistants."),
    BASE_HUNTING("Base Hunting", "Analyze loaded chunks and entities for player activity."),
    MOVEMENT("Movement", "Movement modules."),
    PLAYER("Player", "Player modules."),
    RENDER("Render", "Render modules."),
    UTILITY("Utility", "Utility modules."),
    HUD("HUD", "HUD modules.");

    public final String label, blurb;
    Category(String label, String blurb) { this.label = label; this.blurb = blurb; }
}
