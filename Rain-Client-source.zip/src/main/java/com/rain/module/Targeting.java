package com.rain.module;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import java.util.ArrayList;
import java.util.List;

public final class Targeting {
    private static final Minecraft mc = Minecraft.getInstance();

    public static float wrap(float a) { a %= 360f; if (a >= 180f) a -= 360f; if (a < -180f) a += 360f; return a; }

    public static float yawTo(double dx, double dz) { return (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0); }

    public static float yawTo(Entity e) {
        Vec3 eye = mc.player.getEyePosition(), t = e.getBoundingBox().getCenter();
        return yawTo(t.x - eye.x, t.z - eye.z);
    }

    public static float pitchTo(Entity e) {
        Vec3 eye = mc.player.getEyePosition(), t = e.getBoundingBox().getCenter();
        double dx = t.x - eye.x, dy = t.y - eye.y, dz = t.z - eye.z;
        return (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
    }

    public static boolean eligible(Entity e, boolean players, boolean mobs) {
        if (e == mc.player || !(e instanceof LivingEntity le) || !le.isAlive() || e.isSpectator()) return false;
        return (players && e instanceof Player) || (mobs && e instanceof Mob);
    }

    public static List<LivingEntity> list(double range, boolean players, boolean mobs) {
        List<LivingEntity> out = new ArrayList<>();
        for (Entity e : mc.level.entitiesForRendering())
            if (eligible(e, players, mobs) && mc.player.distanceTo(e) <= range) out.add((LivingEntity) e);
        return out;
    }

    public static LivingEntity best(double range, double fov, boolean players, boolean mobs, String priority) {
        LivingEntity best = null; double bestScore = Double.MAX_VALUE;
        for (LivingEntity e : list(range, players, mobs)) {
            double yawDiff = Math.abs(wrap(yawTo(e) - mc.player.getYRot()));
            if (yawDiff > fov / 2.0) continue;
            double score = switch (priority) {
                case "Angle" -> yawDiff;
                case "Health" -> e.getHealth();
                default -> mc.player.distanceTo(e);
            };
            if (score < bestScore) { bestScore = score; best = e; }
        }
        return best;
    }

    public static String rel(double dx, double dz) {
        float diff = wrap(yawTo(dx, dz) - mc.player.getYRot());
        int a = (int) Math.abs(diff);
        if (a < 15) return "ahead";
        if (a > 165) return "behind";
        return a + " deg " + (diff > 0 ? "right" : "left");
    }

    public static String d(double v) { return String.format("%.1f", v); }
    public static String d3(double v) { return String.format("%.3f", v); }
}
