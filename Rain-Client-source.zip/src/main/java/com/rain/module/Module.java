package com.rain.module;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final Minecraft mc = Minecraft.getInstance();

    public final String name, description;
    public final Category category;
    public int keybind = -1; // GLFW key code, -1 = none
    private boolean enabled;
    private String lastError;
    private String[] hudLines = new String[0];
    protected final List<Setting<?>> settings = new ArrayList<>();

    protected Module(String name, String description, Category category) {
        this.name = name; this.description = description; this.category = category;
    }

    protected Setting<Boolean> bool(String n, boolean d) { Setting<Boolean> s = new Setting<>(n, d, 0, 0); settings.add(s); return s; }
    protected Setting<Double> num(String n, double d, double min, double max) { Setting<Double> s = new Setting<>(n, d, min, max); settings.add(s); return s; }
    protected Setting<String> choice(String n, String d, String... opts) { Setting<String> s = new Setting<>(n, d, opts); settings.add(s); return s; }

    public List<Setting<?>> getSettings() { return settings; }
    public boolean isEnabled() { return enabled; }
    public String getLastError() { return lastError; }
    public String[] hudLines() { return hudLines; }

    public void setEnabled(boolean on) {
        if (on == enabled) return;
        enabled = on;
        if (!on) hudLines = new String[0];
        try { if (on) { lastError = null; onEnable(); } else onDisable(); }
        catch (Throwable t) { fail(t); }
    }
    public void toggle() { setEnabled(!enabled); }

    /** Errors disable only this module, never the client. */
    public final void tick() {
        if (!enabled || mc.player == null || mc.level == null) return;
        try { onTick(); } catch (Throwable t) { fail(t); }
    }

    private void fail(Throwable t) {
        lastError = t.toString();
        enabled = false;
        hudLines = new String[0];
        try { onDisable(); } catch (Throwable ignored) {}
        System.err.println("[Rain] " + name + " disabled after error: " + t);
        t.printStackTrace();
    }

    public void reset() {
        for (Setting<?> s : settings) s.reset();
        keybind = -1;
        setEnabled(false);
    }

    protected void hud(String... lines) { hudLines = lines; }
    protected void chat(String text) {
        if (mc.gui != null) mc.gui.getChat().addMessage(Component.literal("[Rain] " + name + ": " + text));
    }

    protected void onEnable() {}
    protected void onDisable() {}
    protected abstract void onTick();
}
