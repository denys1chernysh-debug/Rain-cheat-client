package com.rain.module;

public class Setting<T> {
    public final String name;
    public final T def;
    public final double min, max;
    public final String[] options; // only for choice settings
    public T value;

    public Setting(String name, T def, double min, double max) {
        this.name = name; this.def = def; this.value = def; this.min = min; this.max = max; this.options = null;
    }
    public Setting(String name, T def, String[] options) {
        this.name = name; this.def = def; this.value = def; this.min = 0; this.max = 0; this.options = options;
    }
    public void reset() { value = def; }

    @SuppressWarnings("unchecked")
    public void set(Object v) {
        if (def instanceof Double && v instanceof Number) {
            value = (T) Double.valueOf(Math.max(min, Math.min(max, ((Number) v).doubleValue())));
        } else if (def instanceof Boolean && v instanceof Boolean) {
            value = (T) v;
        } else if (def instanceof String && v instanceof String && options != null) {
            for (String o : options) if (o.equals(v)) { value = (T) v; return; }
        }
    }

    @SuppressWarnings("unchecked")
    public void cycle() {
        if (options == null) return;
        int i = 0;
        for (int k = 0; k < options.length; k++) if (options[k].equals(value)) i = k;
        value = (T) options[(i + 1) % options.length];
    }
}
