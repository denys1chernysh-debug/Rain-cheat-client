package com.rain.module;

import org.lwjgl.glfw.GLFW;
import java.util.*;

public class ModuleManager {
    private static final List<Module> modules = new ArrayList<>();
    private static final Map<Module, Boolean> keyState = new HashMap<>();

    public static void register(Module m) { modules.add(m); }
    public static List<Module> all() { return Collections.unmodifiableList(modules); }

    public static List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) if (m.category == c) out.add(m);
        return out;
    }

    /** Searches module names AND descriptions across all categories. */
    public static List<Module> search(String q) {
        String s = q == null ? "" : q.trim().toLowerCase();
        List<Module> out = new ArrayList<>();
        for (Module m : modules)
            if (m.name.toLowerCase().contains(s) || m.description.toLowerCase().contains(s)) out.add(m);
        return out;
    }

    public static void tick() { for (Module m : modules) m.tick(); }

    public static void pollKeys(long window, boolean allowed) {
        for (Module m : modules) {
            if (m.keybind < 0) continue;
            boolean down = GLFW.glfwGetKey(window, m.keybind) == GLFW.GLFW_PRESS;
            boolean prev = keyState.getOrDefault(m, false);
            if (down && !prev && allowed) m.toggle();
            keyState.put(m, down);
        }
    }
}
