package com.rain.gui;

import com.rain.module.Module;
import com.rain.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public final class HudManager {
    public static void render(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        int y = 6;
        for (Module m : ModuleManager.all()) {
            if (!m.isEnabled() || m.hudLines().length == 0) continue;
            g.text(mc.font, m.name, 6, y, 0xFF9AA0AB, true); y += 10;
            for (String s : m.hudLines()) {
                if (s == null || s.isEmpty()) continue;
                g.text(mc.font, s, 10, y, 0xFFFFFFFF, true); y += 10;
            }
            y += 4;
        }
    }
}
