package com.rain.gui;

import com.rain.config.UiSettings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** All drawing goes through here so a 26.2 API difference is a one-file fix. */
public final class Gfx {
    public static void fill(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int c) { g.fill(x1, y1, x2, y2, c); }

    public static void text(GuiGraphicsExtractor g, String s, int x, int y, int c) {
        g.text(Minecraft.getInstance().font, s, x, y, c, false);
    }
    public static void bold(GuiGraphicsExtractor g, String s, int x, int y, int c) { text(g, s, x, y, c); text(g, s, x + 1, y, c); }
    public static int width(String s) { return Minecraft.getInstance().font.width(s); }

    public static void rrect(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int c) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { g.fill(x, y, x + w, y + h, c); return; }
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, c);
            g.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, c);
        }
        g.fill(x, y + r, x + w, y + h - r, c);
    }

    public static int argb(int rgb, double alpha) {
        int a = (int) Math.round(Math.max(0, Math.min(1, alpha)) * 255);
        return (a << 24) | (rgb & 0xFFFFFF);
    }
    private static double io() { return UiSettings.interfaceOpacity / 100.0; }
    /** Window / panel backgrounds: interface opacity x (1 - background transparency). */
    public static int bg(int rgb) { return argb(rgb, io() * (1 - UiSettings.backgroundTransparency / 100.0)); }
    /** Buttons / cards: interface opacity x (1 - button transparency). */
    public static int btn(int rgb) { return argb(rgb, io() * (1 - UiSettings.buttonTransparency / 100.0)); }
    /** Text and controls: interface opacity. */
    public static int ui(int rgb) { return argb(rgb, io()); }

    public static String fit(String s, int maxW) {
        if (width(s) <= maxW) return s;
        while (s.length() > 1 && width(s + "...") > maxW) s = s.substring(0, s.length() - 1);
        return s + "...";
    }
}
