package com.rain.gui;

import com.rain.config.ConfigManager;
import com.rain.config.UiSettings;
import com.rain.module.*;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import java.util.*;
import java.util.function.DoubleConsumer;

public class RainScreen extends Screen {
    private static final int WIN = 0x15171C, SIDE = 0x1B1E24, CARD = 0x2A2D35, TXT = 0xE8EAEE, MUTED = 0x8E939E, ON = 0xE5E7EB, OFF = 0x4A4E57, SEL = 0x343841;

    private record Hit(int x1, int y1, int x2, int y2, Runnable click, DoubleConsumer drag) {}

    private static Category cat = Category.COMBAT;
    private static String search = "";
    private boolean searchFocus;
    private double scroll;
    private Module expanded, binding;
    private DoubleConsumer activeDrag;
    private final List<Hit> hits = new ArrayList<>();
    private final long openedAt = System.currentTimeMillis();

    public RainScreen() { super(Component.literal("Rain")); }

    @Override public boolean isPauseScreen() { return false; }

    private void hit(int x, int y, int w, int h, int clipTop, int clipBot, Runnable click, DoubleConsumer drag) {
        int y1 = Math.max(y, clipTop), y2 = Math.min(y + h, clipBot);
        if (y1 >= y2) return;
        hits.add(new Hit(x, y1, x + w, y2, click, drag));
    }

    private void toggleSwitch(GuiGraphicsExtractor g, int x, int y, boolean on) {
        Gfx.rrect(g, x, y, 28, 14, 7, Gfx.ui(on ? ON : OFF));
        Gfx.rrect(g, on ? x + 16 : x + 2, y + 2, 10, 10, 5, Gfx.ui(on ? 0x2A2D35 : 0xC9CCD3));
    }

    private void slider(GuiGraphicsExtractor g, int x, int y, int w, double frac) {
        frac = Math.max(0, Math.min(1, frac));
        Gfx.rrect(g, x, y + 4, w, 4, 2, Gfx.ui(OFF));
        Gfx.rrect(g, x, y + 4, (int) (w * frac), 4, 2, Gfx.ui(ON));
        Gfx.rrect(g, x + (int) (w * frac) - 5, y + 1, 10, 10, 5, Gfx.ui(ON));
    }

    private static List<String> wrap(String s, int maxW) {
        List<String> out = new ArrayList<>(); StringBuilder cur = new StringBuilder();
        for (String w : s.split(" ")) {
            if (cur.length() > 0 && Gfx.width(cur + " " + w) > maxW) { out.add(cur.toString()); cur = new StringBuilder(); }
            if (cur.length() > 0) cur.append(' ');
            cur.append(w);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    private static String keyName(int k) {
        if (k < 0) return "None";
        return switch (k) {
            case 344 -> "R-Shift"; case 340 -> "L-Shift"; case 341 -> "L-Ctrl"; case 345 -> "R-Ctrl"; case 342 -> "L-Alt"; case 346 -> "R-Alt";
            case 32 -> "Space"; case 258 -> "Tab"; case 280 -> "Caps";
            default -> { String n = GLFW.glfwGetKeyName(k, 0); yield n != null ? n.toUpperCase() : "Key " + k; }
        };
    }

    private static List<Module> visible() {
        return search.isBlank() ? ModuleManager.byCategory(cat) : ModuleManager.search(search);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        hits.clear();
        int W = Math.min(width - 20, 1000), H = Math.min(height - 20, 560);
        int X = (width - W) / 2, Y = (height - H) / 2;
        int sw = 150, rw = 230, cx = X + sw, cw = W - sw - rw;

        Gfx.rrect(g, X, Y, W, H, 10, Gfx.bg(WIN));
        Gfx.rrect(g, X + 6, Y + 6, sw - 12, H - 12, 8, Gfx.bg(SIDE));

        // Logo + sidebar
        Gfx.bold(g, "Rain", X + 20, Y + 18, Gfx.ui(TXT));
        Gfx.text(g, "v2.0.0", X + 20, Y + 32, Gfx.ui(MUTED));
        int iy = Y + 56;
        for (Category c : Category.values()) {
            boolean sel = c == cat && search.isBlank();
            if (sel) Gfx.rrect(g, X + 12, iy, sw - 24, 24, 6, Gfx.btn(SEL));
            Gfx.text(g, c.label, X + 24, iy + 8, Gfx.ui(sel ? TXT : MUTED));
            int n = ModuleManager.byCategory(c).size();
            if (n > 0) Gfx.text(g, String.valueOf(n), X + sw - 28, iy + 8, Gfx.ui(MUTED));
            final Category cc = c;
            hit(X + 12, iy, sw - 24, 24, 0, height, () -> { cat = cc; search = ""; scroll = 0; expanded = null; }, null);
            iy += 28;
        }

        // Header
        boolean searching = !search.isBlank();
        Gfx.text(g, "Modules > " + (searching ? "Search" : cat.label), cx + 16, Y + 14, Gfx.ui(MUTED));
        Gfx.bold(g, searching ? "Search results" : cat.label, cx + 16, Y + 28, Gfx.ui(TXT));
        Gfx.text(g, searching ? "Matches in module names and descriptions." : cat.blurb, cx + 16, Y + 44, Gfx.ui(MUTED));
        int sbx = cx + cw - 214, sby = Y + 14;
        Gfx.rrect(g, sbx, sby, 200, 22, 8, Gfx.btn(CARD));
        String shown = search.isEmpty() ? (searchFocus ? "|" : "Search modules...") : search + (searchFocus && (System.currentTimeMillis() / 500) % 2 == 0 ? "|" : "");
        Gfx.text(g, Gfx.fit(shown, 184), sbx + 8, sby + 7, Gfx.ui(search.isEmpty() ? MUTED : TXT));
        hit(sbx, sby, 200, 22, 0, height, () -> searchFocus = true, null);

        // Module list
        int listTop = Y + 66, listBot = Y + H - 12, lx = cx + 16, lw = cw - 32, gap = 8, colW = (lw - gap) / 2;
        List<Module> mods = visible();
        if (mods.isEmpty()) {
            Gfx.text(g, searching ? "No modules match your search." : "No modules in this category yet.", lx, listTop + 10, Gfx.ui(MUTED));
        }
        g.enableScissor(cx, listTop, cx + cw, listBot);
        int y = listTop - (int) scroll, col = 0, rowH = 0, startY = y;
        for (Module m : mods) {
            boolean exp = m == expanded;
            int cardW = exp ? lw : colW;
            if (exp && col == 1) { y += rowH + gap; col = 0; rowH = 0; }
            int x = lx + (exp ? 0 : col * (colW + gap));
            List<String> desc = exp ? wrap(m.description, cardW - 24) : List.of();
            int h = 44;
            if (exp) h = 44 + desc.size() * 11 + 6 + m.getSettings().size() * 22 + 36;
            drawCard(g, m, x, y, cardW, h, exp, desc, listTop, listBot);
            if (exp) { y += h + gap; col = 0; rowH = 0; }
            else { rowH = Math.max(rowH, h); if (col == 1) { y += rowH + gap; col = 0; rowH = 0; } else col = 1; }
        }
        if (col == 1) y += rowH + gap;
        int contentH = y - startY;
        g.disableScissor();
        double max = Math.max(0, contentH - (listBot - listTop));
        scroll = Math.max(0, Math.min(max, scroll));
        if (max > 0) {
            int trackH = listBot - listTop, barH = Math.max(20, (int) (trackH * trackH / (double) contentH));
            int barY = listTop + (int) ((trackH - barH) * (scroll / max));
            Gfx.rrect(g, cx + cw - 8, barY, 3, barH, 1, Gfx.ui(OFF));
        }

        // Right settings panel
        int px = X + W - rw;
        Gfx.fill(g, px, Y + 12, px + 1, Y + H - 12, Gfx.bg(0x2A2D35));
        Gfx.bold(g, "Settings", px + 20, Y + 20, Gfx.ui(TXT));
        Gfx.text(g, "Customize your client.", px + 20, Y + 34, Gfx.ui(MUTED));
        int sy = Y + 70;
        sy = uiSlider(g, px + 20, sy, rw - 40, "Interface Opacity", UiSettings.interfaceOpacity, 10, 100, v -> UiSettings.interfaceOpacity = v);
        sy = uiSlider(g, px + 20, sy, rw - 40, "Button Transparency", UiSettings.buttonTransparency, 0, 100, v -> UiSettings.buttonTransparency = v);
        sy = uiSlider(g, px + 20, sy, rw - 40, "Background Transparency", UiSettings.backgroundTransparency, 0, 100, v -> UiSettings.backgroundTransparency = v);
        Gfx.rrect(g, px + 20, sy + 6, rw - 40, 24, 8, Gfx.btn(CARD));
        Gfx.text(g, "Reset Settings", px + 20 + (rw - 40 - Gfx.width("Reset Settings")) / 2, sy + 14, Gfx.ui(TXT));
        hit(px + 20, sy + 6, rw - 40, 24, 0, height, UiSettings::resetAll, null);
        Gfx.text(g, "RIGHT SHIFT closes this menu.", px + 20, Y + H - 28, Gfx.ui(MUTED));
    }

    private int uiSlider(GuiGraphicsExtractor g, int x, int y, int w, String label, double val, double min, double max, DoubleConsumer setter) {
        Gfx.text(g, label, x, y, Gfx.ui(TXT));
        String v = (int) val + "%";
        Gfx.text(g, v, x + w - Gfx.width(v), y, Gfx.ui(TXT));
        slider(g, x, y + 14, w, (val - min) / (max - min));
        hit(x - 4, y + 10, w + 8, 18, 0, height, null, mx -> setter.accept(Math.round(min + Math.max(0, Math.min(1, (mx - x) / w)) * (max - min))));
        return y + 44;
    }

    private void drawCard(GuiGraphicsExtractor g, Module m, int x, int y, int w, int h, boolean exp, List<String> desc, int top, int bot) {
        if (y + h < top || y > bot) return;
        Gfx.rrect(g, x, y, w, h, 8, Gfx.btn(CARD));
        Gfx.text(g, m.name, x + 12, y + 10, Gfx.ui(TXT));
        String sub = m.getLastError() != null ? "Disabled after an error (see log)" : m.description;
        if (!exp) Gfx.text(g, Gfx.fit(sub, w - 70), x + 12, y + 24, Gfx.ui(MUTED));
        final Module mm = m;
        hit(x, y, w, exp ? 44 : h, top, bot, () -> { expanded = expanded == mm ? null : mm; }, null);
        toggleSwitch(g, x + w - 42, y + 14, m.isEnabled());
        hit(x + w - 46, y + 8, 40, 26, top, bot, () -> { mm.toggle(); ConfigManager.save(); }, null);
        if (!exp) return;
        int yy = y + 44;
        for (String d : desc) { Gfx.text(g, d, x + 12, yy, Gfx.ui(MUTED)); yy += 11; }
        if (m.getLastError() != null) { Gfx.text(g, Gfx.fit("Error: " + m.getLastError(), w - 24), x + 12, yy, Gfx.ui(MUTED)); }
        yy += 6;
        for (Setting<?> s : m.getSettings()) {
            Gfx.text(g, s.name, x + 12, yy + 4, Gfx.ui(TXT));
            int rx = x + w - 12;
            if (s.value instanceof Boolean b) {
                toggleSwitch(g, rx - 28, yy + 2, b);
                @SuppressWarnings("unchecked") Setting<Boolean> sb = (Setting<Boolean>) s;
                hit(rx - 32, yy, 36, 20, top, bot, () -> { sb.value = !sb.value; ConfigManager.save(); }, null);
            } else if (s.value instanceof Double d) {
                int sx = x + (int) (w * 0.5), sw2 = rx - 52 - sx;
                slider(g, sx, yy + 4, sw2, (d - s.min) / (s.max - s.min));
                String vs = (s.max - s.min) <= 10 ? String.format("%.2f", d) : String.valueOf(Math.round(d));
                Gfx.text(g, vs, rx - Gfx.width(vs), yy + 4, Gfx.ui(TXT));
                @SuppressWarnings("unchecked") Setting<Double> sd = (Setting<Double>) s;
                final int fsx = sx, fsw = sw2; final double mn = s.min, mxv = s.max;
                int cy1 = Math.max(yy, top), cy2 = Math.min(yy + 20, bot);
                if (cy1 < cy2) hits.add(new Hit(sx - 4, cy1, sx + sw2 + 4, cy2, null, mx -> {
                    double f = Math.max(0, Math.min(1, (mx - fsx) / fsw));
                    double v = mn + f * (mxv - mn);
                    if ((mxv - mn) > 10) v = Math.round(v); else v = Math.round(v * 100) / 100.0;
                    sd.value = v;
                }));
            } else if (s.value instanceof String str) {
                Gfx.rrect(g, rx - 120, yy, 120, 18, 6, Gfx.btn(SEL));
                Gfx.text(g, str, rx - 120 + (120 - Gfx.width(str)) / 2, yy + 5, Gfx.ui(TXT));
                hit(rx - 120, yy, 120, 18, top, bot, () -> { s.cycle(); ConfigManager.save(); }, null);
            }
            yy += 22;
        }
        // Keybind + reset
        yy += 6;
        String bl = binding == m ? "Press a key..." : "Keybind: " + keyName(m.keybind);
        Gfx.rrect(g, x + 12, yy, 130, 20, 6, Gfx.btn(SEL));
        Gfx.text(g, bl, x + 12 + (130 - Gfx.width(bl)) / 2, yy + 6, Gfx.ui(TXT));
        hit(x + 12, yy, 130, 20, top, bot, () -> binding = mm, null);
        Gfx.rrect(g, x + 150, yy, 80, 20, 6, Gfx.btn(SEL));
        Gfx.text(g, "Reset", x + 150 + (80 - Gfx.width("Reset")) / 2, yy + 6, Gfx.ui(TXT));
        hit(x + 150, yy, 80, 20, top, bot, () -> { mm.reset(); ConfigManager.save(); }, null);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        double mx = e.x(), my = e.y();
        searchFocus = false; binding = binding; 
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (mx >= h.x1 && mx < h.x2 && my >= h.y1 && my < h.y2) {
                if (h.click != null) h.click.run();
                if (h.drag != null) { activeDrag = h.drag; h.drag.accept(mx); }
                return true;
            }
        }
        binding = null;
        return super.mouseClicked(e, dbl);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        if (activeDrag != null) { activeDrag.accept(e.x()); return true; }
        return super.mouseDragged(e, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        if (activeDrag != null) { activeDrag = null; ConfigManager.save(); return true; }
        return super.mouseReleased(e);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double sx, double sy) {
        scroll -= sy * 30;
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        if (binding != null) {
            binding.keybind = k == GLFW.GLFW_KEY_ESCAPE ? -1 : k;
            binding = null; ConfigManager.save(); return true;
        }
        if (searchFocus) {
            if (k == GLFW.GLFW_KEY_BACKSPACE) { if (!search.isEmpty()) search = search.substring(0, search.length() - 1); scroll = 0; return true; }
            if (k == GLFW.GLFW_KEY_ESCAPE) { searchFocus = false; search = ""; return true; }
            if (k == GLFW.GLFW_KEY_ENTER) { searchFocus = false; return true; }
        }
        if (k == GLFW.GLFW_KEY_RIGHT_SHIFT && System.currentTimeMillis() - openedAt > 300) { onClose(); return true; }
        return super.keyPressed(e);
    }

    @Override
    public boolean charTyped(CharacterEvent e) {
        if (searchFocus) {
            int cp = e.codepoint();
            if (cp >= 32 && search.length() < 40) { search += Character.toString(cp); scroll = 0; }
            return true;
        }
        return super.charTyped(e);
    }

    @Override public void onClose() { ConfigManager.save(); super.onClose(); }
}
